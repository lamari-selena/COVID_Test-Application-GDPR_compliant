export type BatchPayload = {
  count: number;
};
export enum dataRequestType {
  RECTIFICATION = 'RECTIFICATION',
  DELETION = 'DELETION',
  FORGET = 'FORGET',
}
